const bar = document.getElementById('bar');
    const menu = document.getElementById('menu');
  
    if (bar) {
      bar.addEventListener('click', () => {
        menu.classList.toggle('active');
      });
    }
  

    const form = document.getElementById('login-form');
    const errorMsg = document.getElementById('error-message');
    const successMsg = document.getElementById('success-message');
  
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();
  
      errorMsg.textContent = '';
      successMsg.textContent = '';
  
      if (username === '' || password === '') {
        errorMsg.textContent = 'Please fill in all fields.';
        errorMsg.style.color = 'red';
      } else {
        successMsg.textContent = 'Login successful!';
        successMsg.style.color = 'green';
  
        
         window.location.href = "dashboard.html";
      }
    });