const landing = document.getElementById('landing-screen');
const professional = document.getElementById('professional-screen');
const volunteer = document.getElementById('volunteer-screen');

document.getElementById('join-professional').addEventListener('click', () => {
  landing.style.display = 'none';
  professional.style.display = 'flex';
});

document.getElementById('join-volunteer').addEventListener('click', () => {
  landing.style.display = 'none';
  volunteer.style.display = 'flex';
});


document.querySelectorAll('.back-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    landing.style.display = 'flex';
    professional.style.display = 'none';
    volunteer.style.display = 'none';
  });
});


document.getElementById('professional-form').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('professional-msg').textContent = "Professional registered successfully!";
  document.getElementById('professional-msg').style.color = "green";
});

document.getElementById('volunteer-form').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('volunteer-msg').textContent = "Volunteer registered successfully!";
  document.getElementById('volunteer-msg').style.color = "green";
});