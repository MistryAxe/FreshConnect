document.addEventListener('DOMContentLoaded', () => {
    const links = {
      "Contact": "contact.html",
      "Join Professional": "Professional/index.html",
      "Join Volunteer": "Volunteer/index.html",
      "Login": "login/index.html"
    };
  
    const navItems = document.querySelectorAll('.navbar nav ul li a');
  
    navItems.forEach(link => {
      const linkText = link.textContent.trim();
      if (links[linkText]) {
        link.addEventListener('click', (e) => {
          e.preventDefault(); 
          window.location.href = links[linkText]; 
        });
      }
    });
  });
  