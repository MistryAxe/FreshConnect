
const regFormContainer = document.getElementById("form-1");
const loginFormContainer = document.getElementById("form-2");
const mainPage = document.getElementById("form-3");


const registrationForm = document.getElementById("registration-Form");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const regError = document.getElementById("error-message");
const regSuccess = document.getElementById("success-message");


const loginForm = document.getElementById("login-form");
const loginUsername = document.getElementById("login-username");
const loginPassword = document.getElementById("login-password");
const loginError = document.getElementById("error-message-login");
const loginSuccess = document.getElementById("success-message-login");

const loginBtn = document.getElementById("login");
const backBtn = document.getElementById("back");


loginBtn.addEventListener("click", () => {
  regFormContainer.style.display = "none";
  loginFormContainer.style.display = "flex";
});


backBtn.addEventListener("click", () => {
  loginFormContainer.style.display = "none";
  regFormContainer.style.display = "flex";
});


registrationForm.addEventListener("submit", (e) => {
  e.preventDefault();
  regError.textContent = "";
  regSuccess.textContent = "";

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!name || !email || !password) {
    regError.textContent = "Please fill in all fields.";
    regError.style.color = "red";
  } else {
    regSuccess.textContent = "Registration successful!";
    regSuccess.style.color = "green";
    registrationForm.reset();
  }
});


loginForm.addEventListener("submit", (e) => {
  e.preventDefault();
  loginError.textContent = "";
  loginSuccess.textContent = "";

  const username = loginUsername.value.trim();
  const password = loginPassword.value.trim();

  if (!username || !password) {
    loginError.textContent = "Please enter both username and password.";
    loginError.style.color = "red";
  } else {
    loginSuccess.textContent = "Login successful!";
    loginSuccess.style.color = "green";


    setTimeout(() => {
      loginFormContainer.style.display = "none";
      mainPage.style.display = "block";
    }, 1000);
  }
});
